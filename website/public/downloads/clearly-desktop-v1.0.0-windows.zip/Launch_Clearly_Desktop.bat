@echo off
title Clearly Desktop OS
echo Starting Clearly Ambient Desktop Engine...
powershell -ExecutionPolicy Bypass -File "%~dp0run_server.ps1"

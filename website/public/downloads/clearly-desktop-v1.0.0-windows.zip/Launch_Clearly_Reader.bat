@echo off
title Clearly Reader Studio
echo Starting Clearly Reader Studio local workspace...
powershell -ExecutionPolicy Bypass -File "%~dp0run_server.ps1"

Clearly Reader Studio — Local Document & Deep Reading Workbench
Version 1.0.0 (Windows / Portable)

Quick Start:
1. Double-click "Launch_Clearly_Reader.bat".
2. Clearly Reader Studio will launch in a dedicated application window at http://localhost:8174.
3. Open any local text or Markdown file, or paste excerpts to deconstruct them across Clearly's canonical lenses.
4. Save key takeaways to your Library and organize study notes locally.

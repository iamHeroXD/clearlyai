Clearly Desktop — Ambient Screen Intelligence & Text Deconstruction
Version 1.0.0 (Windows x64 / Cross-Platform)

Quick Start:
1. Double-click "Launch_Clearly_Desktop.bat".
2. A native standalone desktop window will launch instantly at http://localhost:8174.
3. Use the Global Screen Controller to highlight or snip any text across your desktop apps (PDFs, VS Code, Slack, Terminal).
4. Switch between 6 instant lenses: Polish, Meaning, Simplify, Deconstruct, Counter-argument, and Translation.
5. Press Alt+Space or Ctrl+Shift+C anytime to launch the floating Spotlight HUD.

Online Edition:
You can also use the live Web App version directly without downloading at:
https://clearly-ai-lake.vercel.app/app
